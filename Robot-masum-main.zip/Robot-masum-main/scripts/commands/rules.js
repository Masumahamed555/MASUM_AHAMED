module.exports.config = {
  name: "rules",
  version: "1.0.0",
  permission: 0,
  credits: "ryuko",
  prefix: true,
  description: "rules",
  category: "rules",
  usages: "",
  cooldowns: 5,
};
module.exports.run = async function({ api,event,args,client,Users,Threads,__GLOBAL,Currencies }) {
const axios = global.nodemodule["axios"];
const request = global.nodemodule["request"];
const fs = global.nodemodule["fs-extra"];
const time = process.uptime(),
    hours = Math.floor(time / (60 * 60)),
    minutes = Math.floor((time % (60 * 60)) / 60),
    seconds = Math.floor(time % 60);
const moment = require("moment-timezone");
var juswa = moment.tz("Asia/Dhaka").format("『D/MM/YYYY』 【hh:mm:ss】");
var link = ["https://i.imgur.com/x7NlpQW.jpeg",

            "https://i.imgur.com/x7NlpQW.jpeg", 

            "https://i.imgur.com/x7NlpQW.jpeg",

"",

            ""];

var callback = () => api.sendMessage({body:`╭•┄┅══𝐅𝐀𝐑𝐀𝐍-𝐈𝐒𝐋𝐀𝐌══┅┄•╮\n\nꗥ̳̳̳̳̳̳̳̳̳̳̿̿̿̿̿̿̿̿̿̿⃟ꗥꔸআসসালামু আলাইকুমꔸꗥ⃟ꗥ̳̳̳̳̳̳̳̳̳̳̿̿̿̿̿̿̿̿̿̿\n

•—»গ্রুপ এর কিছু রুলস আছে, এগুলো হয়তো অনেকেই জানেন না যারা জানে না তারা জেনে রাখেন💥

<-------------------------------------------------------------------------->

১) Group এ New Member add হলে তাকে Welcome জানাতে হবে, এবং তার সাথে পরিচয় হতে হবে..☺

২) নিয়মিত  box er call Active থাকতে হবে, এবং call চলা অবস্থায় প্রতিদিন ২ জন করে মেমবার এড করতে হবে 💐

৩) Group এ যে কোনো প্রবলেম হলে সাথে সাথে মিটানোর চেষ্টা করতে হবে, যদি এডমিন দ্বারা পসিবল না হয় তাহলে বক্স কনট্রোলার বা এডভাইজার কে জানাবেন... ☺

৪) Group এ কোনো ধরনের ফালতু কথা,গালাগালি বা 18+ কথা  Video Not Allowed 🔞 সাথে সাথে রিমুভ

৫) বিশেষ প্রয়োজন ছাড়া  কোনো Member কে  Inboxe করবেন না। 

৬)কোন এডমিন যদি  ৮ঘন্টার বেশি কোনো কারন ব্যাতীত  আনএকটিব  থাকে তাহলে তাকে এডমিন থেকে নামানো হবে, যদি সে অসুস্থ থাকে সেটা ভিন্ন ব্যাপার 💥💥💥

৭)  একজন মেমবার এক বক্সেই সীমাবদ্ব থাকবে✌️সেক্ষেত্রে সে অন্য বক্সে আছে কিনা জিগেস করে এড করুন 

৮) প্রতিদিন বক্সে ২ জন করে মেমবার এড করতে হবে, অবশ্যই💐

৯) বক্সে ভদ্রতা এবং শালীন ভাবে নিজেকে উপস্থাপন করবেন

১০)আমাদের উদ্দেশ্য কি সকল মেমবারের সাথে শেয়ার করবেন, (উদ্দেশ্য -- অসহায় মানুষদের সাহায্য করা)

১১) বক্সের কোনো মেয়ের পারমিশন ছাড়া তার ইনবকসে নক করা যাবে না, যদি মেয়েদের বিরক্ত করার কোনো কমপ্লিন আসে তাহলে তাকে আড্ডা এক্সপ্রেস থেকে রিমুভ করা হবে ✌️✌️

১২)  আশা করি আপনারা সবাই রুলস মেনে চলবেন এবং আমাদের সার্পোট করবেন✨«—•

১৩)আর  গ্রুপে কোন কিছু ইনফরমেশন পরিবর্তন করা যাবে না ..without permission! ⚠️

<-------------------------------------------------------------------------->

•—»✨ যারা এই রুলস  গুলা মেনে চলতে পারবেন তারা group থাকেন 🌺আর যারা মানতে পারবেন না লিফট নিবেন, আর রুলস না মানলে সম্মান এর সাথে ব্যান & কিক দেওয়া হবে 🌸༅༎•─

 <-------------------------------------------------------------------------->

•—»✨ যারা বট সম্পক  বুঝেন না, তারা এডমিন কে মেনশন দিয়ে বলবেন আর কোন কমান্ড প্রয়োজন হলে /help এই কমান্ড ব্যবহার করতে পারেন 
★এডমিন এর ফেসবুক আইডি কোনো হেল্প লাগলে নক দিতে পারেন 

https://www.facebook.com/ArYan.com.404

<------------------------------------------------------------------------->___সাথেই থাকুন🌸༅༎•─

ꗥ̳̳̳̳̳̳̳̳̳̳̿̿̿̿̿̿̿̿̿̿⃟ꗥꔸ𝘽𝙊𝙏-𝙊𝙒𝙉𝙀𝙍-𝗙𝗔𝗥𝗛𝗔𝗡-𝗜𝗦𝗟𝗔𝗠ꔸꗥ⃟ꗥ̳̳̳̳̳̳̳̳̳̳̿̿̿̿̿̿̿̿̿̿

─༅༎•🌺ধন্যবাদ সবাইকে🌸༅༎•─\n\n╰•┄┅═♥︎╣[-𝖠𝖱𝖸𝖠𝖭-]╠♥︎═┅┄•╯`,attachment: fs.createReadStream(__dirname + "/cache/juswa.jpg")}, event.threadID, () => fs.unlinkSync(__dirname + "/cache/juswa.jpg")); 
      return request(encodeURI(link[Math.floor(Math.random() * link.length)])).pipe(fs.createWriteStream(__dirname+"/cache/juswa.jpg")).on("close",() => callback());
   };
